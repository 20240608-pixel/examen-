const cotizar = parseFloat(document.getElementById("btnCotizar").value); 
